package com.imaginative.imaginative;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImaginativeApplicationTests {

	@Test
	void contextLoads() {
	}

}
